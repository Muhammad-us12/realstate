<?php

namespace App\Http\Controllers\website;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\locations\Societies;
use App\Models\website\BlogCategory;
use App\Models\website\Blogs;

use App\Models\website\OffersCategory;
use App\Models\website\Offers;

use App\Models\website\VideoCategory;
use App\Models\website\Video;
use App\Models\Location;
use App\Models\locations\LocalProperty;


class WebsiteController extends Controller
{
    //
    public function index(){
        $Location_data = Location::all();
        // $societies_data = Societies::all();
        $scoeities = Societies::where('display_on_web',1)->orderBy("id","desc")->limit(6)->get();
        // print_r($scoeities);

        // die;
        return view('website.index',compact('scoeities','Location_data'));
    }

    public function search_property(Request $request){
        $Location_data = Location::all();
        $properties = LocalProperty::where('location_id',$request->location)
                        ->where('society_id',$request->society_id)
                        ->where('state_type',$request->property_type)
                        ->get();
        // print_r($properties);
        return view('website.search_property_list',compact('properties','Location_data'));
    }

    public function property_detail($id){
        $properties = LocalProperty::find($id);
        return view('website.property_detail',compact('properties'));
    }

    public function blog_list()
    {
        //
        $blogs_data = Blogs::where('status','publish')->orderBy("id","desc")->paginate(10);
        $allCategories = BlogCategory::all();

        
        return view('website.blogs.blogs_list',compact('blogs_data','allCategories'));
       
    }

    public function offers_list()
    {
        //
        $offers_data = Offers::where('status','publish')->orderBy("id","desc")->paginate(10);
        $allCategories = OffersCategory::all();

        
        return view('website.offers.offers_list',compact('offers_data','allCategories'));
       
    }

    public function category_blogs($id)
    {
        $blogs_data = Blogs::where('status','publish')
        ->where('blog_category',$id)
        ->orderBy("id","desc")->paginate(10);
        $allCategories = BlogCategory::all();

        
        return view('website.blogs.category_blogs_list',compact('blogs_data','allCategories'));
    }

    public function category_offers($id)
    {
        $offers_data = Offers::where('status','publish')
        ->where('offer_category',$id)
        ->orderBy("id","desc")->paginate(10);
        $allCategories = OffersCategory::all();

        // print_r($offers_data);
        // die;
        return view('website.offers.category_offers_list',compact('offers_data','allCategories'));
    }

    public function category_videos($id)
    {
        $video_data = Video::where('status','publish')
        ->where('video_category',$id)
        ->orderBy("id","desc")->paginate(10);
        $allCategories = VideoCategory::all();

        // print_r($offers_data);
        // die;
        return view('website.videos.videos_cat_list',compact('video_data','allCategories'));
    }

    

    public function blog_details($id)
    {
        $blogs_data = Blogs::find($id);
        $allCategories = BlogCategory::all();

        
        return view('website.blogs.blog_details',compact('blogs_data','allCategories'));
    }

    public function offers_details($id)
    {
        $offer_data = Offers::find($id);
        $allCategories = OffersCategory::all();

        
        return view('website.offers.offers_details',compact('offer_data','allCategories'));
    }

    public function videos_list()
    {
        //
        $video_data = Video::where('status','publish')->orderBy("id","desc")->paginate(10);
        $allCategories = VideoCategory::all();

        
        return view('website.videos.videos_list',compact('video_data','allCategories'));
       
    }

    public function video_details($id)
    {
        $video_data = Video::find($id);
        $allCategories = VideoCategory::all();

        
        return view('website.videos.video_details',compact('video_data','allCategories'));
    }
    
    
    

    
}
